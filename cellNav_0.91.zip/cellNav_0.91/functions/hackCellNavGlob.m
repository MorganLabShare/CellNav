%hackCelNavGlob()

global glob

glob.NA.export.fix.changeZ = -1;



