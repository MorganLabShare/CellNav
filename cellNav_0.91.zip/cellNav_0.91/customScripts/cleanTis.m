%takes in a tis, returns one that has removed:
% all objects with no voxels or anchors (empty segs)
% all synapses with no positions
% all redundant synapses