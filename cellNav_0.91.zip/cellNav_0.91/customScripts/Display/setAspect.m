%%Find translations for improving alignment 
%%between each plane of segmentations stored as dsObj
% 
% fig = figure;
% 
% global tis glob
% if 1
% load('MPN.mat')
% load([MPN 'Merge\dsObj.mat'])
% end
% 

disp('This function has been replaced with defining voxel size during import from VAST')




