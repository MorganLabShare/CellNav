function makeMPNcnv


global glob
MPN = glob.NA.MPN;
WPN = glob.NA.WPN;
save('MPN.mat','MPN', 'WPN')