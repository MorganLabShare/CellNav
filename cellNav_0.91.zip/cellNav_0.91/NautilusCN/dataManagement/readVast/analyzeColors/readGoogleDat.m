function[datRaw] = readGoogleDat(datSheet,GID)


datRaw = GetGoogleSpreadsheet2(datSheet,GID);
