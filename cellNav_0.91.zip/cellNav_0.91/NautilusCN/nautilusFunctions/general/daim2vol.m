function[equivialantVol] = daim2vol(diams)


equivialantVol = 4/3 * pi * (diams/2)^3;