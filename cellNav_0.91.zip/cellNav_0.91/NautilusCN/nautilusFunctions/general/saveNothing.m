function[] = saveNothing(saveName)

save(saveName,'saveName')