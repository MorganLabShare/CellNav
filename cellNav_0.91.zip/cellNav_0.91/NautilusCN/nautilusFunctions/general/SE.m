function[se] = SE(vals)

std(vals)/sqrt(length(vals))