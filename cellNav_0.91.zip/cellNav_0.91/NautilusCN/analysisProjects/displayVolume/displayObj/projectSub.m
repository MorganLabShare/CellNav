function[projSub] = projectSub(sub,dim)

dim = 1;

