

axTCRs = [944 160 448 451 454 455 303 456 184 303 187 160 486]

% suspected axon dendrite convergence on 303, 420 and 944;
% 420, 303 looks like a likey convergence